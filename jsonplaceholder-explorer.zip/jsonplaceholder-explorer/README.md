# JSONPlaceholder Explorer

Aplicación web que consume y muestra información de la API pública [JSONPlaceholder](https://jsonplaceholder.typicode.com/).

## Recursos consumidos

- `/comments`
- `/albums`
- `/photos`
- `/todos`
- `/users`

## Tecnologías

- HTML5
- CSS3
- JavaScript (Fetch API)

No requiere instalación de dependencias ni backend propio: todo corre en el navegador.

## Cómo ejecutar

1. Clonar el repositorio.
2. Abrir `index.html` en el navegador, o usar la extensión **Live Server** de VS Code (clic derecho sobre el archivo → *Open with Live Server*).

## Funcionalidades

- Navegación entre los distintos recursos de la API mediante pestañas.
- Búsqueda/filtro en tiempo real sobre los datos cargados.
- Paginación de resultados.
- Tarjetas con estadísticas (totales, completados/pendientes en *todos*).
- Diseño responsivo adaptado a cada tipo de recurso (usuarios, fotos, tareas, álbumes, comentarios).
