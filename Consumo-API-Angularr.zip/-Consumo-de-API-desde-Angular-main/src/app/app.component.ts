import { ChangeDetectorRef, Component } from '@angular/core';
import { User } from './features/users/model/user.model';
import { UserService } from './features/users/services/user.service';

@Component({
  standalone: false,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  users: User[] = [];

  constructor(
    private userService: UserService,
    private cdr: ChangeDetectorRef
  ) {}

  cargarUsuarios() {
    this.userService.getUsers().subscribe({
      next: (data) => {
        this.users = data;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('FALLÓ, REVISE:', err);
      },
      complete: () => {
        console.log('Usuarios cargados correctamente');
      }
    });
  }
}